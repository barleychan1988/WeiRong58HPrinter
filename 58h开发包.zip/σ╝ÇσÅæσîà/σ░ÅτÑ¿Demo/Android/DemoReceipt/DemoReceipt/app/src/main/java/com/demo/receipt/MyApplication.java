package com.demo.receipt;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;

import com.demo.receipt.Manaer.PrintfManager;
import com.demo.receipt.Manaer.SharedPreferencesManager;
import com.demo.receipt.Utils.StaticVar;
import com.demo.receipt.Utils.Util;
import com.qd.receipt.R;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyApplication extends Application {

    ExecutorService cachedThreadPool = null;

    public ExecutorService getCachedThreadPool() {
        return cachedThreadPool;
    }


    private Handler handler = new Handler();

    public Handler getHandler() {
        return handler;
    }

    static MyApplication instance = null;

    public static MyApplication getInstance(){
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        cachedThreadPool = Executors.newCachedThreadPool();
        cachedThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.logo);
                int left = PrintfManager.getCenterLeft(72, bitmap);
                byte[] bytes = PrintfManager.bitmap2PrinterBytes(bitmap, left);
                StaticVar.bitmap_80 = bytes;
                left = PrintfManager.getCenterLeft(48,bitmap);
                bytes = PrintfManager.bitmap2PrinterBytes(bitmap, left);
                StaticVar.bitmap_58 = bytes;
            }
        });
        Util.changLanguage(instance, SharedPreferencesManager.getLanguageId(instance));
    }
}
