package com.demo.receipt.Activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.demo.receipt.Manaer.PrintfManager;
import com.demo.receipt.Modle.Mode;
import com.demo.receipt.Utils.MyContextWrapper;
import com.demo.receipt.Utils.Util;
import com.qd.receipt.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private TextView tv_main_bluetooth;
    private Button btn_main_test_80,btn_main_test_58,btn_main_test_bold;

    private RadioGroup rg_main_test;
    private RadioButton rb_main_test_bold,rb_main_test_no_bold;

    private EditText et_main_test_size;

    private List<Mode> listData;

    private PrintfManager printfManager;

    private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        initView();
        initData();
        setLister();
    }

    private void setLister() {

        btn_main_test_bold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = et_main_test_size.getText().toString();
                int size = 1;
                if(Util.isNumeric(s)){
                    size = Integer.valueOf(s);
                }
                //需要打印的字体，要加上换行，不然打印机不会打印
                //If you need to print a font, add a new line, or the printer will not print it.
                printfManager.printf_bold_size("Welcome to use\n",size,rb_main_test_bold.isChecked());
            }
        });

        printfManager.addBluetoothChangLister(new PrintfManager.BluetoothChangLister() {
            @Override
            public void chang(String name, String address) {
                tv_main_bluetooth.setText(name);
            }
        });

        tv_main_bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PrintfBlueListActivity.startActivity(MainActivity.this);
            }
        });

        btn_main_test_80.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(printfManager.isConnect()){
                    printfManager.printf_80(
                            context.getString(R.string.TEST),
                            context.getString(R.string.godown_keeper)
                            ,context.getString(R.string.send_printer),listData
                    );
                }else{
                   PrintfBlueListActivity.startActivity(MainActivity.this);
                }
            }
        });

        btn_main_test_58.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(printfManager.isConnect()){
                    printfManager.printf_50(
                            context.getString(R.string.TEST),
                            context.getString(R.string.godown_keeper)
                            ,context.getString(R.string.send_printer),listData
                    );
                }else{
                    PrintfBlueListActivity.startActivity(MainActivity.this);
                }
            }
        });
    }

    private void initData() {
        printfManager = PrintfManager.getInstance(context);
        listData = new ArrayList<>();
        listData.add(new Mode("Test-P26",200,320));
        listData.add(new Mode("Test-P16",20,188));
        printfManager.defaultConnection();
    }

    private void initView() {
        btn_main_test_80 = (Button)findViewById(R.id.btn_main_test_80);
        btn_main_test_58 = (Button)findViewById(R.id.btn_main_test_58);
        tv_main_bluetooth = (TextView)findViewById(R.id.tv_main_bluetooth);
        et_main_test_size = (EditText)findViewById(R.id.et_main_test_size);
        btn_main_test_bold = (Button)findViewById(R.id.btn_main_test_bold);

        rg_main_test = (RadioGroup)findViewById(R.id.rg_main_test);
        rb_main_test_bold = (RadioButton)findViewById(R.id.rb_main_test_bold);
        rb_main_test_no_bold = (RadioButton)findViewById(R.id.rb_main_test_no_bold);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = MyContextWrapper.wrap(newBase);
        super.attachBaseContext(context);
    }

}
