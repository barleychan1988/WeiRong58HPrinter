package com.demo.receipt.Utils;

/**
 * Created by Administrator on 2018/1/2.
 */

public class StaticVar {

    public static byte[] bitmap_58;
    public static byte[] bitmap_80;

}
