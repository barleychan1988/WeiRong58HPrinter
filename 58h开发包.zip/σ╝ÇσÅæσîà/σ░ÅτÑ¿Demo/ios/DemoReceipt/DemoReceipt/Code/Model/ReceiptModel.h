//
//  ReceiptModel.h
//  DemoReceipt
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 receipt printf demo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ReceiptModelInner.h"

NS_ASSUME_NONNULL_BEGIN

@interface ReceiptModel : NSObject

@property (assign,nonatomic)BOOL isBold;

//字体大小
@property (assign,nonatomic)int fontSize;

//公司名称
@property (strong,nonatomic)NSString *companyName;

//操作人
@property (strong,nonatomic)NSString *operatorPeople;

//备注
@property (strong,nonatomic)NSString *remark;

@property (strong,nonatomic)NSArray<ReceiptModelInner *> *models;

@end

NS_ASSUME_NONNULL_END
