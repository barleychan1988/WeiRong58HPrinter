//
//  ReceiptModelInner.m
//  DemoReceipt
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 receipt printf demo. All rights reserved.
//

#import "ReceiptModelInner.h"

@implementation ReceiptModelInner

@end
