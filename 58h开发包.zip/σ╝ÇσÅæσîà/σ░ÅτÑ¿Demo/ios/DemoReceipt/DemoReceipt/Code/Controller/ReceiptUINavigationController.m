//
//
//  Created by Mac on 2018/10/17.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import "ReceiptUINavigationController.h"

@interface ReceiptUINavigationController ()


@end

@implementation ReceiptUINavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    UINavigationBar *navBar = [UINavigationBar appearance];
//    UINavigationBar *navBar = [self UINavigationBar appearance];
    navBar.barTintColor = TotalColor;
    
    UIFont *font = [UIFont systemFontOfSize:(17)];
    navBar.titleTextAttributes = @{NSFontAttributeName:font,NSForegroundColorAttributeName:UIColor.whiteColor};
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if(self.viewControllers.count > 0){
        [viewController setHidesBottomBarWhenPushed:false];
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"navBack"] style:UIBarButtonItemStylePlain target:self action:@selector(navigationBack:)];
    }
    [super pushViewController:viewController animated:true];
}

-(void)navigationBack:(UIButton*)uiButton{
    UIViewController *uiViewController = self.topViewController;
    [self popViewControllerAnimated:true];
}

@end
