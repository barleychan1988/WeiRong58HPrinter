//
//  BluetoothController.h
//
//  Created by Mac on 2018/11/6.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BluetoothController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (strong,nonatomic)void (^callBackBluetoothName)(NSString *bluetoothName);

@end

NS_ASSUME_NONNULL_END
