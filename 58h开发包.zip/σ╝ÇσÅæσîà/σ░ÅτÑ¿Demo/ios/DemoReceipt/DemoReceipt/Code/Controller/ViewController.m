//
//  ViewController.m
//  DemoReceipt
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 receipt printf demo. All rights reserved.
//

#import "ViewController.h"

#import "BluetoothController.h"
#import "BluetoothManager.h"

#import "ReceiptModel.h"
#import "ReceiptModelInner.h"
#import "ReceiptPrintfUtils.h"
@interface ViewController ()

@property (strong,nonatomic) UILabel *blueNameUILabel;

@property (strong,nonatomic) UILabel *test58Label;

@property (strong,nonatomic) UILabel *test80Label;

@property (strong,nonatomic) UILabel *testIsBoldLabel;

@property (strong,nonatomic) UITextField *uiTextField;

@property (strong,nonatomic) UISwitch *isBoldUISwitch;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initView];
    
    [self addGesture];

    [self registerNotice];
}

-(void)addGesture{
    
    [self.blueNameUILabel setUserInteractionEnabled:true];
    UITapGestureRecognizer *blueNameTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(blueNameAction:)];
    [self.blueNameUILabel addGestureRecognizer:blueNameTapGestureRecognizer];

    [self.test58Label setUserInteractionEnabled:true];
    UITapGestureRecognizer *test58TapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(test58Action:)];
    [self.test58Label addGestureRecognizer:test58TapGestureRecognizer];
    
    [self.test80Label setUserInteractionEnabled:true];
    UITapGestureRecognizer *test80TapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(test80Action:)];
    [self.test80Label addGestureRecognizer:test80TapGestureRecognizer];
    
    [self.testIsBoldLabel setUserInteractionEnabled:true];
    UITapGestureRecognizer *testIsBoldGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(testIsBoldAction:)];
    [self.testIsBoldLabel addGestureRecognizer:testIsBoldGestureRecognizer];
    
//    [self.isBoldUISwitch addTarget:self action:@selector(isBoldAction:) forControlEvents:UIControlEventValueChanged];
    
}

-(void)testIsBoldAction:(UITapGestureRecognizer *)recognizer{
    
    BluetoothManager *bluetoothManager = [BluetoothManager bluetoothManagerInstance];
    if(![bluetoothManager isConnected]){
        [ReceiptUtils ToastText:getInterString(@"蓝牙未连接")];
        return;
    }
    
    NSString *text = self.uiTextField.text;
    int fontSize = 14;
    if(![text isEqualToString:@""]){
        fontSize = [text intValue];
    }
    
    BOOL isBold = [self.isBoldUISwitch isOn];
    
    NSString *sendText = getInterString(@"美恒通");
    
    NSData *tempNSData = [CommonUtils textToGBKNSData:sendText];
    
    
    NSMutableData *sendNSData = [[NSMutableData alloc] initWithCapacity:5];

    if(isBold){
        Byte boldOn[3];
        boldOn[0] = 27;
        boldOn[1] = 69;
        boldOn[2] = 1;
        [sendNSData appendData:[[NSData alloc] initWithBytes:boldOn length:3]];
    }
    
    Byte fontSizeByte[3];
    fontSizeByte[0] = 0x1b;
    fontSizeByte[1] = 0x21;
    fontSizeByte[2] = fontSize;
    
    [sendNSData appendData:[[NSData alloc] initWithBytes:fontSizeByte length:3]];
    
    [sendNSData appendData:tempNSData];
    
    fontSizeByte[2] = 0;
    
    [sendNSData appendData:[[NSData alloc] initWithBytes:fontSizeByte length:3]];
    
    if(isBold){
        Byte boldOn[3];
        boldOn[0] = 27;
        boldOn[1] = 69;
        boldOn[2] = 0;
        [sendNSData appendData:[[NSData alloc] initWithBytes:boldOn length:3]];
    }
    
    [sendNSData appendData:[CommonUtils textToGBKNSData:@"\n\n\n"]];
    
    if(![bluetoothManager writeNSData:sendNSData]){
        [ReceiptUtils ToastText:getInterString(@"正在打印...")];
    }
}

//-(void)isBoldAction:(id)sender{
//
//    UISwitch *uiSwitch = (UISwitch *)sender;
//    if([uiSwitch isOn]){
//
//    }
//
//}

-(void)test80Action:(UITapGestureRecognizer *)recognizer{
    
    BluetoothManager *bluetoothManager = [BluetoothManager bluetoothManagerInstance];
    if(![bluetoothManager isConnected]){
        [ReceiptUtils ToastText:getInterString(@"未连接蓝牙")];
        return;
    }
    
    ReceiptModel *receiptModel = [[ReceiptModel alloc] init];
    receiptModel.companyName = getInterString(@"TEST");
    receiptModel.operatorPeople = getInterString(@"仓库管理员");
    receiptModel.remark = getInterString(@"发最新版的机子");
    
    NSMutableArray<ReceiptModelInner *> *tempReceiptModelInners = [NSMutableArray arrayWithCapacity:5];
    
    ReceiptModelInner *tempReceiptModelInner = [[ReceiptModelInner alloc] init];
    tempReceiptModelInner.name = @"TEST-test";
    tempReceiptModelInner.number = 200;
    tempReceiptModelInner.price = 320;
    [tempReceiptModelInners addObject:tempReceiptModelInner];
    
    ReceiptModelInner *tempReceiptModelInner1 = [[ReceiptModelInner alloc] init];
    tempReceiptModelInner1.name = @"TEST-test";
    tempReceiptModelInner1.number = 20;
    tempReceiptModelInner1.price = 188;
    [tempReceiptModelInners addObject:tempReceiptModelInner1];
    receiptModel.models = tempReceiptModelInners;
    
    NSData *nsData = [ReceiptPrintfUtils to80ReceiptNSData:receiptModel];
    
    if([bluetoothManager writeNSData:nsData]){
        [ReceiptUtils ToastText: getInterString(@"正在打印...")];
    }
}

-(void)test58Action:(UITapGestureRecognizer *)recognizer{
    
    BluetoothManager *bluetoothManager = [BluetoothManager bluetoothManagerInstance];
    if(![bluetoothManager isConnected]){
        [ReceiptUtils ToastText:getInterString(@"未连接蓝牙")];
        return;
    }
    
    ReceiptModel *receiptModel = [[ReceiptModel alloc] init];
    receiptModel.companyName = getInterString(@"TEST");
    receiptModel.operatorPeople = getInterString(@"仓库管理员");
    receiptModel.remark = getInterString(@"发最新版的机子");
    
    NSMutableArray<ReceiptModelInner *> *tempReceiptModelInners = [NSMutableArray arrayWithCapacity:5];
    
    ReceiptModelInner *tempReceiptModelInner = [[ReceiptModelInner alloc] init];
    tempReceiptModelInner.name = @"TEST-test";
    tempReceiptModelInner.number = 200;
    tempReceiptModelInner.price = 320;
    [tempReceiptModelInners addObject:tempReceiptModelInner];
    
    ReceiptModelInner *tempReceiptModelInner1 = [[ReceiptModelInner alloc] init];
    tempReceiptModelInner1.name = @"TEST-test";
    tempReceiptModelInner1.number = 20;
    tempReceiptModelInner1.price = 188;
    [tempReceiptModelInners addObject:tempReceiptModelInner1];
    receiptModel.models = tempReceiptModelInners;

    NSData *nsData = [ReceiptPrintfUtils to58ReceiptNSData:receiptModel];
    
    if([bluetoothManager writeNSData:nsData]){
        [ReceiptUtils ToastText: getInterString(@"正在打印...")];
    }
}

-(void)bluetoothChange:(NSNotification *)notification{
    BluetoothManager *bluetoothManager = [BluetoothManager bluetoothManagerInstance];
    NSString *blueName = [bluetoothManager getCurrentName];
    self.blueNameUILabel.text = [getInterString(@"当前蓝牙:") stringByAppendingString:blueName];
}

/**
 * 注册通知
 */
-(void)registerNotice{
    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
    [defaultCenter addObserver:self selector:@selector(bluetoothChange:) name:@"printfNameChange" object:nil];
}

-(void)blueNameAction:(UITapGestureRecognizer *)recognizer{
    BluetoothController *controller = [[BluetoothController alloc] init];
    [self.navigationController pushViewController:controller animated:true];
}

-(void)initView{
    
    self.view.backgroundColor = UIColor.whiteColor;
    
    CGFloat endY = getRectNavAndStatusHight + 10;
    
    endY = [self initTest58Label:endY];

    endY = [self initTest80Label:endY + 10];

    endY = [self initFontSizeUIView:endY + 10];//字体大小
    
    endY = [self initIsBoldUIView:endY + 10];//是否粗体
    
    endY = [self initTestIsBoldLabel:endY + 10];//测试加粗字体的UILabel
    
    endY = [self initBlueNameLabel:endY + 10];//蓝牙名称
}

/**
 * 创造 测试80Lablel
 * creat test 80 label
 */
-(CGFloat)initTest80Label:(CGFloat)startY{
    self.test80Label = [[UILabel alloc] init];
    self.test80Label.text = getInterString(@"测试 80MM 小票");
    self.test80Label.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.test80Label.backgroundColor = UIColor.grayColor;
    self.test80Label.textColor = UIColor.whiteColor;
    self.test80Label.textAlignment = NSTextAlignmentCenter;
    self.test80Label.layer.cornerRadius = 10;
    self.test80Label.layer.masksToBounds = true;
    [self.view addSubview:self.test80Label];
    return self.test80Label.frame.origin.y + self.test80Label.frame.size.height;
}

/**
 * 创造 测试58Lablel
 * craet test 58 label
 */
-(CGFloat)initTest58Label:(CGFloat)startY{
    self.test58Label = [[UILabel alloc] init];
    self.test58Label.text = getInterString(@"测试 58MM 小票");
    self.test58Label.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.test58Label.backgroundColor = UIColor.grayColor;
    self.test58Label.textColor = UIColor.whiteColor;
    self.test58Label.textAlignment = NSTextAlignmentCenter;
    self.test58Label.layer.cornerRadius = 10;
    self.test58Label.layer.masksToBounds = true;
    [self.view addSubview:self.test58Label];
    return self.test58Label.frame.origin.y + self.test58Label.frame.size.height;
}
 
/**
 * 创造字体大小
 */
-(CGFloat)initFontSizeUIView:(CGFloat)startY{
    
    UIView *uiView = [[UIView alloc] init];
    uiView.frame = CGRectMake(0, startY, SCREEN_W, 50);
    [self.view addSubview:uiView];
    
    //字体大小
    //font Size
    UILabel *fontUILabel = [[UILabel alloc] init];
    NSString *fontText = getInterString(@"字体大小");
    fontUILabel.text = fontText;
    CGFloat width = [CommonUtils getNSStringWidth:fontText font:fontUILabel.font];
    fontUILabel.frame = CGRectMake(10, 0, width, uiView.frame.size.height);
    [uiView addSubview:fontUILabel];
    
    //输入框
    //Input box
    self.uiTextField = [[UITextField alloc] init];
    self.uiTextField.frame = CGRectMake(
                                 fontUILabel.frame.size.width + fontUILabel.frame.origin.x + 10,
                                 10,
                                 uiView.frame.size.width - 10 - fontUILabel.frame.size.width - 20,
                                 uiView.frame.size.height - 20
                                );
    self.uiTextField.keyboardType = UIKeyboardTypeNumberPad;
    self.uiTextField.layer.borderWidth = 1;
    self.uiTextField.layer.borderColor = UIColor.blackColor.CGColor;
    [uiView addSubview:self.uiTextField];
    
    return uiView.frame.origin.y + uiView.frame.size.height;
}

/**
 * 是否要加粗
 * is Bold
 */
-(CGFloat)initIsBoldUIView:(CGFloat)startY{
    
    UIView *uiView = [[UIView alloc] init];
    uiView.frame = CGRectMake(0, startY, SCREEN_W, 50);
    [self.view addSubview:uiView];
    
    //是否要加粗 UILabel
    //is Blold UILabel
    UILabel *isBoldUILabel = [[UILabel alloc] init];
    NSString *fontText = getInterString(@"是否粗体");
    isBoldUILabel.text = fontText;
    CGFloat width = [CommonUtils getNSStringWidth:fontText font:isBoldUILabel.font];
    isBoldUILabel.frame = CGRectMake(10, 0, width, uiView.frame.size.height);
    [uiView addSubview:isBoldUILabel];
    
    //开关
    //open close
    self.isBoldUISwitch = [[UISwitch alloc] init];
    self.isBoldUISwitch.frame = CGRectMake(isBoldUILabel.frame.origin.x + isBoldUILabel.frame.size.width + 10,
                                     (uiView.frame.size.height - self.isBoldUISwitch.frame.size.height) / 2,
                                      0,
                                      0);
    
    [self.isBoldUISwitch setTintColor:Color(139,136,120)];
    [self.isBoldUISwitch setOnTintColor:Color(84, 255, 159)];
    [self.isBoldUISwitch setThumbTintColor:Color(139,136,120)];
    self.isBoldUISwitch.layer.cornerRadius = 15.5f;
    self.isBoldUISwitch.layer.masksToBounds = YES;
    [uiView addSubview:self.isBoldUISwitch];
    
    return uiView.frame.origin.y + uiView.frame.size.height;
}

/**
 * 创造 测试加粗字体
 * craet test is Bold font
 */
-(CGFloat)initTestIsBoldLabel:(CGFloat)startY{
    self.testIsBoldLabel = [[UILabel alloc] init];
    self.testIsBoldLabel.text = getInterString(@"测试加粗字体");
    self.testIsBoldLabel.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.testIsBoldLabel.backgroundColor = UIColor.grayColor;
    self.testIsBoldLabel.textColor = UIColor.whiteColor;
    self.testIsBoldLabel.textAlignment = NSTextAlignmentCenter;
    self.testIsBoldLabel.layer.cornerRadius = 10;
    self.testIsBoldLabel.layer.masksToBounds = true;
    [self.view addSubview:self.testIsBoldLabel];
    return self.testIsBoldLabel.frame.origin.y + self.testIsBoldLabel.frame.size.height;
}

/**
 * 创造当前蓝牙名称
 */
-(CGFloat)initBlueNameLabel:(CGFloat)startY{
    self.blueNameUILabel = [[UILabel alloc] init];
    self.blueNameUILabel.text = getInterString(@"未连接蓝牙");
    self.blueNameUILabel.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.blueNameUILabel.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:self.blueNameUILabel];
    return self.blueNameUILabel.frame.origin.y + self.blueNameUILabel.frame.size.height;
}

@end
