//
//  BluetoothController.m
//
//  Created by Mac on 2018/11/6.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import "BluetoothController.h"
#import "BluetoothModel.h"
#import "BluetoothManager.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "BluetoothUITableViewCell.h"

#define NO_SCANNING 0
#define SCANNING 1

@interface BluetoothController ()

@property (assign,nonatomic) int type;

@property (strong,nonatomic) UILabel *bluetoothUILabel;
@property (strong,nonatomic) UITableView *bluetoothDeviceUITableView;
//集合
@property (strong,nonatomic) NSMutableArray<BluetoothModel *>* bluetoothModels;

//蓝牙管理器
@property (strong,nonatomic) BluetoothManager *bluetoothManager;

@property (strong,nonatomic) UIBarButtonItem *searchUIBarButtonItem;

@end

@implementation BluetoothController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.type = SCANNING;
    
    [self initView];
    self.bluetoothModels = [NSMutableArray arrayWithCapacity:5];
    self.bluetoothManager = [BluetoothManager bluetoothManagerInstance];
   
    [self initBlock];
    
    [self beginScan];
}

- (void)viewDidDisappear:(BOOL)animated{
    [self.bluetoothManager stopScan];
}

-(void)initBlock{
     __weak typeof(self) weakSelf = self;
    self.bluetoothManager.scanBlueName = ^(CBPeripheral * _Nonnull peripheral) {
        NSString *uuid = peripheral.identifier.UUIDString;

        for(int i = 0; i < weakSelf.bluetoothModels.count;i++){
            BluetoothModel *bluetoothModel = weakSelf.bluetoothModels[i];
            NSString *tempUUID = bluetoothModel.peripheral.identifier.UUIDString;
            if([uuid isEqualToString:tempUUID]){
                return;
            }
        }
        
        BluetoothModel *bluetoothModel = [[BluetoothModel alloc] init];
        bluetoothModel.peripheral = peripheral;
        [weakSelf.bluetoothModels addObject:bluetoothModel];
        [weakSelf.bluetoothDeviceUITableView reloadData];
    };
    
    self.bluetoothManager.connectSuccess = ^{
        [ReceiptUtils ToastText:getInterString(@"连接成功")];
        [weakSelf.navigationController popViewControllerAnimated:true];
    };
}

-(void)initView{
    CGFloat endY = getRectNavAndStatusHight;
    self.view.backgroundColor = Color(204, 204, 204);
    
    [self setTitleBar];
    
    endY = [self initBluetoothUILabel:endY];
    endY = [self initBluetoothDeviceUITableView:endY];
}

-(void)setTitleBar{
    self.title = getInterString(@"蓝牙列表");
    
    self.searchUIBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:getInterString(@"搜索中") style:UIBarButtonItemStylePlain target:self action:@selector(clickSearchUIBarButtonItem:)];
    [self.searchUIBarButtonItem setTintColor:UIColor.whiteColor];
    self.navigationItem.rightBarButtonItem = self.searchUIBarButtonItem;
}

-(void)clickSearchUIBarButtonItem:(id)paramSender{
    if(self.type == SCANNING){
        self.type = NO_SCANNING;
        [self.bluetoothManager scanStop];
    }else if(self.type == NO_SCANNING){
        self.type = SCANNING;
        [self beginScan];
    }
    [self changeUIBarButtonItemByType];
}

-(void)beginScan{
    [self.bluetoothModels removeAllObjects];
    [self.bluetoothManager beginScan];
}

/**
 * 改变搜索按钮的状态，根据类型
 */
-(void)changeUIBarButtonItemByType{
    if(self.type == SCANNING){
        self.searchUIBarButtonItem.title = getInterString(@"搜索中");
    }else if(self.type == NO_SCANNING){
        self.searchUIBarButtonItem.title = getInterString(@"搜索");
    }
}

-(CGFloat)initBluetoothDeviceUITableView:(CGFloat)startY{
    
    self.bluetoothDeviceUITableView = [[UITableView alloc] init];
    self.bluetoothDeviceUITableView.frame = CGRectMake(0, startY, SCREEN_W, SCREEN_H - startY);
//    self.bluetoothDeviceUITableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.bluetoothDeviceUITableView.showsVerticalScrollIndicator = false;
    self.bluetoothDeviceUITableView.showsHorizontalScrollIndicator = false;
    self.bluetoothDeviceUITableView.delegate = self;
    self.bluetoothDeviceUITableView.dataSource = self;
    [self.view addSubview:self.bluetoothDeviceUITableView];
    
    return self.bluetoothDeviceUITableView.frame.origin.y + self.bluetoothDeviceUITableView.frame.size.height;
}

-(CGFloat)initBluetoothUILabel:(CGFloat)startY{

    self.bluetoothUILabel = [[UILabel alloc] init];
    self.bluetoothUILabel.frame = CGRectMake(10, startY, SCREEN_W, 35);
    self.bluetoothUILabel.text = getInterString(@"蓝牙列表");
    self.bluetoothUILabel.textAlignment = NSTextAlignmentLeft;
//    self.bluetoothUILabel.backgroundColor = Color(204, 204, 204);
    [self.view addSubview:self.bluetoothUILabel];
    
    return self.bluetoothUILabel.frame.origin.y + self.bluetoothUILabel.frame.size.height;
}

//返回一个cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    int row = (int)indexPath.row;
    
    BluetoothModel *bluetoothModel = self.bluetoothModels[row];
    
    BluetoothUITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell == nil){
        cell = [[BluetoothUITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        [cell initUIView: CGSizeMake(SCREEN_W, 50)];
    }
    
    NSString *name = bluetoothModel.peripheral.name;
    NSString *uuid = bluetoothModel.peripheral.identifier.UUIDString;
    [cell setData:name withUUID:uuid];
    
    return cell;
}

//返回cell的数量
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.bluetoothModels.count;
}

//点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    int row = (int)indexPath.row;
    BluetoothModel *bluetoothModel = self.bluetoothModels[row];
    [self.bluetoothManager connect:bluetoothModel.peripheral];
}

//返回高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

@end
