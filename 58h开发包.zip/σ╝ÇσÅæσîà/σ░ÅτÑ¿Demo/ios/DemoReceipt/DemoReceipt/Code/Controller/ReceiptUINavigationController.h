//
//
//  Created by Mac on 2018/10/17.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ReceiptUINavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
