//
//  TimeUtils.m
//
//  Created by Mac on 2018/12/1.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import "TimeUtils.h"

static NSMutableArray<NSString *> *yearMonthDayNSArray;

static NSMutableArray<NSString *> *timeBranchSecondNSArray;

@implementation TimeUtils

/**
 * 得到默认格式
 */
+(NSString *)getDefaultFormat{
    return @"yyyy-MM-dd hh:mm";
}

/**
 * 得到年月日的格式化 数组
 */
+(NSArray<NSString *> *)getYearFormat{
    if(yearMonthDayNSArray == nil){
        yearMonthDayNSArray = [[NSMutableArray alloc] init];
        [yearMonthDayNSArray addObject:@"yyyy年MM月dd日"];
        [yearMonthDayNSArray addObject:@"yyyy年MM月"];
        [yearMonthDayNSArray addObject:@"MM月dd日"];
        [yearMonthDayNSArray addObject:@"yyyy-MM-dd"];
        [yearMonthDayNSArray addObject:@"yyyy-MM"];
        [yearMonthDayNSArray addObject:@"yyyy-dd"];
        [yearMonthDayNSArray addObject:@"yyyy/MM/dd"];
        [yearMonthDayNSArray addObject:@"yyyy/MM"];
        [yearMonthDayNSArray addObject:@"yyyy/dd"];
        [yearMonthDayNSArray addObject:@"MM-dd-yyyy"];
    }
    return yearMonthDayNSArray;
}

/**
 * 得到时 分 秒 的格式化 数组
 */
+(NSArray<NSString *> *)getTimeFormat{
    if(timeBranchSecondNSArray == nil){
        timeBranchSecondNSArray = [[NSMutableArray alloc] init];
        [timeBranchSecondNSArray addObject:@"hh:mm:ss"];
        [timeBranchSecondNSArray addObject:@"hh:mm"];
        [timeBranchSecondNSArray addObject:@"mm:ss"];
    }
    return timeBranchSecondNSArray;
}


/**
 * 得到当前时间
 * format:时间格式
 * day:日期偏移
 */
+(NSString *) getData:(NSString *)format day:(int)day{
    return [TimeUtils getData:format dayInterval:day * 86400];
}

/**
 * 得到当前时间
 * format:时间格式
 * dayInterval:日期偏移的时间戳
 */
+(NSString *) getData:(NSString *)format dayInterval:(double)dayInterval{
    NSDate *nsDate = [[NSDate alloc] init];
    NSTimeInterval timeInterval = nsDate.timeIntervalSince1970;
    double newTimeInterval = timeInterval + dayInterval;
    NSDate *nowNSDate = [[NSDate alloc] initWithTimeIntervalSince1970:newTimeInterval];
    NSDateFormatter *nsDateFormatter = [[NSDateFormatter alloc] init];
    nsDateFormatter.dateFormat = format;
    NSString *tempDate = [nsDateFormatter stringFromDate:nowNSDate];
    return tempDate;
}

/**
 * 得到当前时间 默认时间戳，无日期偏移
 */
+(NSString *) getData{
    return [TimeUtils getData:[TimeUtils getDefaultFormat] dayInterval:0];
}

@end
