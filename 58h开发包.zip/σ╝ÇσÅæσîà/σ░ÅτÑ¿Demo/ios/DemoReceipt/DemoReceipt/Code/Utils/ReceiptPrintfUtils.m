//
//  ReceiptPrintfUtils.m
//  DemoReceipt
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 receipt printf demo. All rights reserved.
//

#import "ReceiptPrintfUtils.h"

@implementation ReceiptPrintfUtils

+(NSData *)to80ReceiptNSData:(ReceiptModel *)receiptModel{
    
    NSMutableData *nsData = [[NSMutableData alloc] initWithCapacity:5];
    
    NSData *tempNSData = nil;
    
    UIImage *uiImage = [UIImage imageNamed:@"logo"];
    tempNSData = [ReceiptPrintfUtils escCovertToGrayScaleWithImage:uiImage left:[ReceiptPrintfUtils getCenterLeft:72 image:uiImage]];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printTwoColumn:getInterString(@"公司名称") content:receiptModel.companyName paperMM:72];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfWrap:1];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printTwoColumn:getInterString(@"操作人") content:receiptModel.operatorPeople paperMM:72];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfWrap:1];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printTwoColumn:getInterString(@"时间") content:[TimeUtils getData] paperMM:72];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfWrap:1];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfPlueLine_80];
    [nsData appendData:tempNSData];
    
    NSString *tempText = getInterString(@"类型");
    tempNSData = [CommonUtils textToGBKNSData:tempText];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfTabSpace:14];
    [nsData appendData:tempNSData];
    
    tempText = getInterString(@"数量");
    tempNSData = [CommonUtils textToGBKNSData:tempText];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfTabSpace:10];
    [nsData appendData:tempNSData];
    
    tempText = getInterString(@"价格");
    tempNSData = [CommonUtils textToGBKNSData:tempText];
    [nsData appendData:tempNSData];
    
    [nsData appendData:[ReceiptPrintfUtils printfWrap:1]];
    
    NSArray<ReceiptModelInner *> *tempNSArray = receiptModel.models;
    for(int i = 0; i < tempNSArray.count; i++){
        ReceiptModelInner *receiptModelInner = tempNSArray[i];
        tempText = receiptModelInner.name;
        NSData *nameNSData = [CommonUtils textToGBKNSData:tempText];
        [nsData appendData:nameNSData];
        
        int supplementNumber = nameNSData.length - 4;
        [nsData appendData:[ReceiptPrintfUtils printfTabSpace:(14 - supplementNumber)]];
        
        NSString *numberNSString = [NSString stringWithFormat:@"%0.2f",receiptModelInner.number];
        NSData *numberNSStringNSData = [CommonUtils textToGBKNSData:numberNSString];
        [nsData appendData: numberNSStringNSData];
        
        supplementNumber = numberNSStringNSData.length - 4;
        [nsData appendData:[ReceiptPrintfUtils printfTabSpace:10 - supplementNumber]];
        
        NSString *totalPrice = [NSString stringWithFormat:@"%0.2f",receiptModelInner.price * receiptModelInner.number];
        [nsData appendData:[CommonUtils textToGBKNSData:totalPrice]];
        
        [nsData appendData:[ReceiptPrintfUtils printfWrap:1]];
    }
    [nsData appendData:[ReceiptPrintfUtils printfPlueLine_80]];
    [nsData appendData:[CommonUtils textToGBKNSData:getInterString(@"备注")]];
    [nsData appendData:[ReceiptPrintfUtils printfWrap:1]];
    [nsData appendData:[CommonUtils textToGBKNSData:receiptModel.remark]];
    [nsData appendData:[ReceiptPrintfUtils printfWrap:4]];
    return nsData;
}

+(NSData *)to58ReceiptNSData:(ReceiptModel *)receiptModel{
    
    NSMutableData *nsData = [[NSMutableData alloc] initWithCapacity:5];
    
    NSData *tempNSData = nil;
    
    UIImage *uiImage = [UIImage imageNamed:@"logo"];
    tempNSData = [ReceiptPrintfUtils escCovertToGrayScaleWithImage:uiImage left:[ReceiptPrintfUtils getCenterLeft:48 image:uiImage]];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printTwoColumn:getInterString(@"公司名称") content:receiptModel.companyName paperMM:48];
     [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfWrap:1];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printTwoColumn:getInterString(@"操作人") content:receiptModel.operatorPeople paperMM:48];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfWrap:1];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printTwoColumn:getInterString(@"时间") content:[TimeUtils getData] paperMM:48];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfWrap:1];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfPlusLine_58];
    [nsData appendData:tempNSData];
    
    NSString *tempText = getInterString(@"类型");
    tempNSData = [CommonUtils textToGBKNSData:tempText];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfTabSpace:6];
    [nsData appendData:tempNSData];
    
    tempText = getInterString(@"数量");
    tempNSData = [CommonUtils textToGBKNSData:tempText];
    [nsData appendData:tempNSData];
    
    tempNSData = [ReceiptPrintfUtils printfTabSpace:4];
    [nsData appendData:tempNSData];
    
    tempText = getInterString(@"价格");
    tempNSData = [CommonUtils textToGBKNSData:tempText];
    [nsData appendData:tempNSData];
    
    [nsData appendData:[ReceiptPrintfUtils printfWrap:1]];
    
    NSArray<ReceiptModelInner *> *tempNSArray = receiptModel.models;
    for(int i = 0; i < tempNSArray.count; i++){
        ReceiptModelInner *receiptModelInner = tempNSArray[i];
        tempText = receiptModelInner.name;
        NSData *nameNSData = [CommonUtils textToGBKNSData:tempText];
        [nsData appendData:nameNSData];
        
        int supplementNumber = nameNSData.length - 4;
        [nsData appendData:[ReceiptPrintfUtils printfTabSpace:(6 - supplementNumber)]];
        
        NSString *numberNSString = [NSString stringWithFormat:@"%0.2f",receiptModelInner.number];
        NSData *numberNSStringNSData = [CommonUtils textToGBKNSData:numberNSString];
        [nsData appendData: numberNSStringNSData];
        
        supplementNumber = numberNSStringNSData.length - 4;
        [nsData appendData:[ReceiptPrintfUtils printfTabSpace:4 - supplementNumber]];
        
        NSString *totalPrice = [NSString stringWithFormat:@"%0.2f",receiptModelInner.price * receiptModelInner.number];
        [nsData appendData:[CommonUtils textToGBKNSData:totalPrice]];
        
        [nsData appendData:[ReceiptPrintfUtils printfWrap:1]];
    }
    [nsData appendData:[ReceiptPrintfUtils printfPlusLine_58]];
    [nsData appendData:[CommonUtils textToGBKNSData:getInterString(@"备注")]];
    [nsData appendData:[ReceiptPrintfUtils printfWrap:1]];
    [nsData appendData:[CommonUtils textToGBKNSData:receiptModel.remark]];
    [nsData appendData:[ReceiptPrintfUtils printfWrap:4]];
    return nsData;
}

+(NSData *)printfTabSpace:(int)length{
    NSMutableString * tempText = [[NSMutableString alloc] initWithCapacity:5];
    for(int i = 0; i < length; i++){
        [tempText appendString:@" "];
    }
    return [CommonUtils textToGBKNSData:tempText];
}

+(NSData *)printfPlueLine_80{
    NSString *line = @"- - - - - - - - - - - - - - - - - - - - - - -\n";
    return [CommonUtils textToGBKNSData:line];
}

+(NSData *)printfPlusLine_58{
    NSString *line = @"- - - - - - - - - - - - - - - -\n";
    return [CommonUtils textToGBKNSData:line];
}

/**
 * 打印换行
 */
+(NSData *)printfWrap:(int)number{
    
    NSMutableString *text = [[NSMutableString alloc] initWithCapacity:5];
    for(int i = 0; i < number; i++){
        [text appendString:@"\n"];
    }
    
    return [CommonUtils textToGBKNSData:text];
}
 

/**
 * 打印两列
 */
+(NSData *)printTwoColumn:(NSString *)title content:(NSString *)content paperMM:(int)paperMM{
    
    NSMutableData *totalData = [[NSMutableData alloc] initWithCapacity:5];
    
    [totalData appendData:[CommonUtils textToGBKNSData:title]];
    
    NSData *tempNSData = [ReceiptPrintfUtils setLocation:[ReceiptPrintfUtils getOffset:content paperMM:paperMM]];
    [totalData appendData:tempNSData];
    
    [totalData appendData:[CommonUtils textToGBKNSData:content]];
    
    return totalData;
}

+(int)getOffset:(NSString *)str paperMM:(int)paperMM{
    return paperMM * 8 - [ReceiptPrintfUtils getStringPixLength:str];
}

+(int)getStringPixLength:(NSString *)str{
    int pixLength = 0;
    unichar ch;
    for(int i = 0; i < str.length; i++){
        ch = [str characterAtIndex:i];
        if (0x4E00 <= ch  && ch <= 0x9FA5) {//是中文
            pixLength = pixLength + 24;
        }else{//不是中文
            pixLength = pixLength + 12;
        }
    }
    return pixLength;
}

/**
 * 设置绝对打印位置
 */
+(NSData *)setLocation:(int)offset{
    Byte data[4];
    data[0] = 0x1B;
    data[1] = 0x24;
    data[2] = offset % 256;
    data[3] = offset / 256;
    return [[NSData alloc] initWithBytes:data length:4];
}


/**
 * 得到居中的左边距
 * get center left maragin
 */
+(int)getCenterLeft:(int)paperWidth image:(UIImage *)image {
    int width = image.size.width;
    float imagePaperWidth = width / 8;
    int realPaperWidth = paperWidth / 2 - imagePaperWidth / 2;
    return realPaperWidth;
}

+ (NSData *)escCovertToGrayScaleWithImage:(UIImage *)image left:(int) left{
    int width =image.size.width;
    int height =image.size.height;

    //像素将画在这个数组
    uint32_t *pixels = (uint32_t *)malloc(width *height *sizeof(uint32_t));
    //清空像素数组
    memset(pixels, 0, width*height*sizeof(uint32_t));

    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();

    //用 pixels 创建一个 context
    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width*sizeof(uint32_t), colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), image.CGImage);

    int tt = 1;
    int s = 0;

    Byte bytes[(width / 8 + left + 4) * height];
    Byte bitbuf[width / 8];
    int p[8]={0,0,0,0,0,0,0,0};
    for (int y = 0; y <height; y++) {
        for (int x =0; x <width/8; x ++) {
            for(int z = 0; z < 8; z++){
                uint8_t *rgbaPixel = (uint8_t *)&pixels[(y*width)+(x* 8+z)];

                int red = rgbaPixel[tt];
                int green = rgbaPixel[tt + 1];
                int blue = rgbaPixel[tt + 2];
                int gray = 0.29900 * red + 0.58700 * green + 0.11400 * blue; // 灰度转化公式
                if (gray <= 128) {
                    gray = 1;
                } else {
                    gray = 0;
                }
                p[z] = gray;
            }
            int value = (p[0] * 128 + p[1] * 64 + p[2] * 32 + p[3] * 16 + p[4] * 8 + p[5] * 4 + p[6] * 2 + p[7]);
            bitbuf[x] = value;
        }

        if(y != 0) {
            s = s+1;
            bytes[s] = 22;
        } else {
            bytes[s] = 22;
        }

        s = s + 1;
        bytes[s] = (width / 8 + left);

        for(int i = 0; i < left; i++){
            s = s + 1;
            bytes[s] = 0;
        }

        for(int n = 0; n < width/8;n++){
            s = s + 1;
            bytes[s] = bitbuf[n];
        }

        s = s + 1;
        bytes[s] = 21;
        s = s + 1;
        bytes[s] = 1;
    }
    free(pixels);
    NSData *data = [NSData dataWithBytes: bytes length: sizeof(bytes)];
    return data;
}

@end
