//
//  ReceiptPrintfUtils.h
//  DemoReceipt
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 receipt printf demo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ReceiptModel.h"
#import "ReceiptModelInner.h"

NS_ASSUME_NONNULL_BEGIN

@interface ReceiptPrintfUtils : NSObject

+(NSData *)to58ReceiptNSData:(ReceiptModel *)receiptModel;

+(NSData *)to80ReceiptNSData:(ReceiptModel *)receiptModel;

@end

NS_ASSUME_NONNULL_END
