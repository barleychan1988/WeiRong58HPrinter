//
//  TimeUtils.h
//
//  Created by Mac on 2018/12/1.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TimeUtils : NSObject

/**
 * 得到默认格式
 */
+(NSString *)getDefaultFormat;

/**
 * 得到年月日的格式化 数组
 */
+(NSArray<NSString *> *)getYearFormat;

/**
 * 得到时 分 秒 的格式化 数组
 */
+(NSArray<NSString *> *)getTimeFormat;

/**
 * 得到当前时间
 * format:时间格式
 * day:日期偏移
 */
+(NSString *) getData:(NSString *)format day:(int)day;

/**
 * 得到当前时间
 * format:时间格式
 * dayInterval:日期偏移的时间戳
 */
+(NSString *) getData:(NSString *)format dayInterval:(double)dayInterval;

/**
 * 得到当前时间 默认时间戳，无日期偏移
 */
+(NSString *) getData;

@end

NS_ASSUME_NONNULL_END
