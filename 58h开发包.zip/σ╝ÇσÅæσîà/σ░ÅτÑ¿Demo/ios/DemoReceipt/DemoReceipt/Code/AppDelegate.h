//
//  AppDelegate.h
//  DemoReceipt
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 receipt printf demo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

