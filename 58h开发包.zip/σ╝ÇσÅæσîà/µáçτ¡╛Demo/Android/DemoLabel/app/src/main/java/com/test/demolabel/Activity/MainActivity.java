package com.test.demolabel.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.test.demolabel.Manaer.PrintfManager;
import com.test.demolabel.Modle.Mode;
import com.test.demolabel.R;

import java.util.List;

public class MainActivity extends Activity {

    private TextView tv_main_bluetooth;
    private Button btn_main_test_p26,btn_main_test_p16;

    private List<Mode> listData;

    private PrintfManager printfManager;

    private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        initView();
        initData();
        setLister();
    }

    private Bitmap decodeResource(Resources resources, int id) {
        TypedValue value = new TypedValue();
        resources.openRawResource(id, value);
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inTargetDensity = value.density;
        return BitmapFactory.decodeResource(resources, id, opts);
    }

    private void setLister() {

        btn_main_test_p26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bitmap bitmap = decodeResource(getResources(),R.mipmap.p_tow_six);
                printfManager.printf(72,50,bitmap,MainActivity.this);
            }
        });

        btn_main_test_p16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bitmap bitmap = decodeResource(getResources(),R.mipmap.p_one_six);
                printfManager.printf(48,50,bitmap,MainActivity.this);
            }
        });

        printfManager.addBluetoothChangLister(new PrintfManager.BluetoothChangLister() {
            @Override
            public void chang(String name, String address) {
                tv_main_bluetooth.setText(name);
            }
        });

        tv_main_bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PrintfBlueListActivity.startActivity(MainActivity.this);
            }
        });

    }

    private void initData() {
        printfManager = PrintfManager.getInstance(context);
        printfManager.defaultConnection();
    }

    private void initView() {
        btn_main_test_p26 = (Button)findViewById(R.id.btn_main_test_p26);
        btn_main_test_p16 = (Button)findViewById(R.id.btn_main_test_p16);
        tv_main_bluetooth = (TextView)findViewById(R.id.tv_main_bluetooth);
    }
}
