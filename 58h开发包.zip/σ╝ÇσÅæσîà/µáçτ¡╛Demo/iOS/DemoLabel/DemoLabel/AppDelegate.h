//
//  AppDelegate.h
//  DemoLabel
//
//  Created by Mac on 2018/12/7.
//  Copyright © 2018年 label printf demo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

