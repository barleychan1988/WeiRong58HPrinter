//
//  ViewController.m
//  DemoLabel
//
//  Created by Mac on 2018/12/7.
//  Copyright © 2018年 label printf demo. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
