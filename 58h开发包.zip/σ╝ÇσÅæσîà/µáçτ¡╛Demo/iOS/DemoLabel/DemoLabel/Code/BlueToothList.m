//
//  BlueToothList.m
//  bultoothText
//
//  Created by SuperMan on 2018/3/23.
//  Copyright © 2018年 Foshan New Media Technology Co., Ltd. All rights reserved.
//

#import "BlueToothList.h"
#import "BlueToothManager.h"
static NSString *reusedID = @"UITableViewCellRid";

@interface BlueToothList()

@end
@implementation BlueToothList{
    NSArray *_blueToothListArray;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    UILabel *labeel = [[UILabel alloc] initWithFrame:CGRectMake(14, 0, [UIScreen mainScreen].bounds.size.width, 40)];
    labeel.textColor = [UIColor blueColor];
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(14, 40, [UIScreen mainScreen].bounds.size.width, 0.5)];
    line.alpha = 0.5;
    line.backgroundColor = [UIColor grayColor];
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 40)];
    [header addSubview:line];
    [header addSubview:labeel];
    labeel.text = @"请选择你需要连接的设备";
    [self.tableView setTableHeaderView:header];
    //去除多余cell的下划线
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    
    
    [BlueToothManager.shareBlueToothManager statSearchPeripheral];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reusedID];
    
    
    
    
    __weak typeof (self)weakSelf = self;
    [BlueToothManager shareBlueToothManager].searchAllCBPeripheralHandler = ^(NSArray *array) {
        _blueToothListArray = array;
        
        
        [weakSelf.tableView reloadData];
    };
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _blueToothListArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reusedID forIndexPath:indexPath];
    CBPeripheral *Peripheral = _blueToothListArray[indexPath.row];
    cell.textLabel.text = Peripheral.name;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CBPeripheral *Peripheral = _blueToothListArray[indexPath.row];
    //连接外设
    [[BlueToothManager shareBlueToothManager].cMgr connectPeripheral:Peripheral options:nil];
    [self.navigationController popViewControllerAnimated:YES];
}


@end
