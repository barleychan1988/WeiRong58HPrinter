//
//  ViewController.m
//  bultoothText
//
//  Created by SuperMan on 2018/3/22.
//  Copyright © 2018年 Foshan New Media Technology Co., Ltd. All rights reserved.
//

#import "ViewController.h"
#import "BluetoothManager.h"
#import "LabelPrinterUtils.h"
#import "BluetoothController.h"
#import "LabelModel.h"

@interface ViewController ()

@property (strong,nonatomic) UILabel *blueNameUILabel;

@property (strong,nonatomic) UILabel *test80Label;

@property (strong,nonatomic) UILabel *test58Label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initView];
    
    [self addGesture];

    [self registerNotice];
}

/**
 * 注册通知
 */
-(void)registerNotice{
    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
    [defaultCenter addObserver:self selector:@selector(bluetoothChange:) name:@"printfNameChange" object:nil];
}

-(void)bluetoothChange:(NSNotification *)notification{
    BluetoothManager *bluetoothManager = [BluetoothManager bluetoothManagerInstance];
    NSString *blueName = [bluetoothManager getCurrentName];
    self.blueNameUILabel.text = [getInterString(@"当前蓝牙:") stringByAppendingString:blueName];
}

-(void)addGesture{
    
    [self.blueNameUILabel setUserInteractionEnabled:true];
    UITapGestureRecognizer *blueNameTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(blueNameAction:)];
    [self.blueNameUILabel addGestureRecognizer:blueNameTapGestureRecognizer];
    
    [self.test58Label setUserInteractionEnabled:true];
    UITapGestureRecognizer *test58TapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(test58Action:)];
    [self.test58Label addGestureRecognizer:test58TapGestureRecognizer];
    
    [self.test80Label setUserInteractionEnabled:true];
    UITapGestureRecognizer *test80TapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(test80Action:)];
    [self.test80Label addGestureRecognizer:test80TapGestureRecognizer];
}

-(void)test58Action:(UITapGestureRecognizer *)recognizer{
    BluetoothManager *blueToothManager = [BluetoothManager bluetoothManagerInstance];
    if(![blueToothManager isConnected]){
        [ReceiptUtils ToastText:getInterString(@"蓝牙未连接")];
        return;
    }
    UIImage *uiImage = [UIImage imageNamed:@"p_one_six"];
    //更换图片的尺寸
    uiImage = [CommonUtils reSizeImage:uiImage toSize:CGSizeMake(48 * 8, 50 * 8)];
    LabelModel *labelModel = [[LabelModel alloc] init];
    labelModel.labelHeight = 50;
    labelModel.labelWidth = 48;
    labelModel.printfUIImage = uiImage;
    NSData *nsData = [LabelPrinterUtils toLabelNSData:labelModel number:1];
    if([blueToothManager writeNSData:nsData]){
        return [ReceiptUtils ToastText:getInterString(@"正在打印...")];
    }
}

-(void)test80Action:(UITapGestureRecognizer *)recognizer{
    BluetoothManager *blueToothManager = [BluetoothManager bluetoothManagerInstance];
    if(![blueToothManager isConnected]){
        [ReceiptUtils ToastText:getInterString(@"蓝牙未连接")];
        return;
    }
    UIImage *uiImage = [UIImage imageNamed:@"p_tow_six"];
    //更换图片的尺寸
    uiImage = [CommonUtils reSizeImage:uiImage toSize:CGSizeMake(72 * 8, 50 * 8)];
    LabelModel *labelModel = [[LabelModel alloc] init];
    labelModel.labelHeight = 50;
    labelModel.labelWidth = 72;
    labelModel.printfUIImage = uiImage;
    NSData *nsData = [LabelPrinterUtils toLabelNSData:labelModel number:1];
    if([blueToothManager writeNSData:nsData]){
        return [ReceiptUtils ToastText:getInterString(@"正在打印...")];
    }
}

-(void)blueNameAction:(UITapGestureRecognizer *)recognizer{
    BluetoothController *controller = [[BluetoothController alloc] init];
    [self.navigationController pushViewController:controller animated:true];
}

-(void)initView{
    
    self.view.backgroundColor = UIColor.whiteColor;
    
    CGFloat endY = getRectNavAndStatusHight + 10;
    
    endY = [self initTest80Label:endY + 10];
    
    endY = [self initTest58Label:endY + 10];
    
    endY = [self initBlueNameLabel:endY];
    
}

/**
 * 创造 测试80Lablel
 * creat test 80 label
 */
-(CGFloat)initTest80Label:(CGFloat)startY{
    self.test80Label = [[UILabel alloc] init];
    self.test80Label.text = getInterString(@"测试 80 * 50 标签");
    self.test80Label.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.test80Label.backgroundColor = UIColor.grayColor;
    self.test80Label.textColor = UIColor.whiteColor;
    self.test80Label.textAlignment = NSTextAlignmentCenter;
    self.test80Label.layer.cornerRadius = 10;
    self.test80Label.layer.masksToBounds = true;
    [self.view addSubview:self.test80Label];
    return self.test80Label.frame.origin.y + self.test80Label.frame.size.height;
}

/**
 * 创造 测试58Lablel
 * craet test 58 label
 */
-(CGFloat)initTest58Label:(CGFloat)startY{
    self.test58Label = [[UILabel alloc] init];
    self.test58Label.text = getInterString(@"测试 57 * 50 标签");
    self.test58Label.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.test58Label.backgroundColor = UIColor.grayColor;
    self.test58Label.textColor = UIColor.whiteColor;
    self.test58Label.textAlignment = NSTextAlignmentCenter;
    self.test58Label.layer.cornerRadius = 10;
    self.test58Label.layer.masksToBounds = true;
    [self.view addSubview:self.test58Label];
    return self.test58Label.frame.origin.y + self.test58Label.frame.size.height;
}

/**
 * 创造当前蓝牙名称
 */
-(CGFloat)initBlueNameLabel:(CGFloat)startY{
    self.blueNameUILabel = [[UILabel alloc] init];
    self.blueNameUILabel.text = getInterString(@"未连接蓝牙");
    self.blueNameUILabel.frame = CGRectMake(10, startY, SCREEN_W - 20, 50);
    self.blueNameUILabel.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:self.blueNameUILabel];
    return self.blueNameUILabel.frame.origin.y + self.blueNameUILabel.frame.size.height;
}

@end
