//
//  LabelModel.m
//  DemoLabel
//
//  Created by Mac on 2018/12/8.
//  Copyright © 2018年 label printf demo. All rights reserved.
//

#import "LabelModel.h"

@implementation LabelModel

@end
