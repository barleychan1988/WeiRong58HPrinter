//
//  BluetoothModel.m
//
//  Created by Mac on 2018/11/6.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import "BluetoothModel.h"

@implementation BluetoothModel

@end
