//
//  BlueToothManager.h
//  bultoothText
//
//  Created by SuperMan on 2018/3/22.
//  Copyright © 2018年 Foshan New Media Technology Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#define getInterString(str) NSLocalizedString(str,str)
@interface BlueToothManager : NSObject
+(instancetype)shareBlueToothManager;
@property (copy,nonatomic)void(^searchAllCBPeripheralHandler)(NSArray *array);//返回有效外设数组
//中心管理者
@property (nonatomic, strong) CBCentralManager *cMgr;
// 连接到的外设 /
@property (nonatomic, strong) CBPeripheral *peripheral;
@property (strong,nonatomic)NSMutableArray *peripheralsArray;//获取所有强度40到80的设备  储存起来
- (void)statSearchPeripheral;//开始搜索设备
-(void)printQRCodeWithImg:(UIImage *)QRCode withText:(NSString *)text;

-(void)escPrintImage:(UIImage *)image;

-(void)escPrintTex:(NSString *)text;

@end
