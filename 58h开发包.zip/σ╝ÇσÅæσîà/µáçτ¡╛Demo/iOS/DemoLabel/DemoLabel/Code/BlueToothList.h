//
//  BlueToothList.h
//  bultoothText
//
//  Created by SuperMan on 2018/3/23.
//  Copyright © 2018年 Foshan New Media Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#define getInterString(str) NSLocalizedString(str,str)
@interface BlueToothList : UITableViewController

@end
