//
//  BluetoothUITableViewCell.h
//
//  Created by Mac on 2018/11/6.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BluetoothUITableViewCell : UITableViewCell

/**
 * 设置数据，uuid代表蓝牙的唯一标识
 */
-(void)setData:(NSString *)bluetoothName withUUID:(NSString *)uuid;

-(void)initUIView:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
