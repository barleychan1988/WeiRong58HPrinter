//
//  BlueToothManager.m
//  bultoothText
//
//  Created by SuperMan on 2018/3/22.
//  Copyright © 2018年 Foshan New Media Technology Co., Ltd. All rights reserved.
//

#import "BlueToothManager.h"
#import "MBProgressHUD.h"
#import <CoreImage/CoreImage.h>
#import <UIKit/UIKit.h>
@interface BlueToothManager()<CBCentralManagerDelegate,CBPeripheralDelegate,UIAlertViewDelegate>

@property (strong,nonatomic)CBCharacteristic *characteristic;//保存外设设备特征
@end
@implementation BlueToothManager


-(void)escPrintTex:(NSString *)text {
    if (!self.characteristic || text == nil) {
        return;
    }
    //转成GBK
    NSStringEncoding gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData *data = [text dataUsingEncoding:gbkEncoding];
    
    [self.peripheral writeValue:data forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
}

-(void)escPrintImage:(UIImage *)image {
    if (!self.characteristic) {
        return;
    }
    NSData *imageData = [self escCovertToGrayScaleWithImage:image left:0];
    
    [self.peripheral writeValue:imageData forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
}

//第一个参数是已连接的蓝牙设备 ；第二个参数是要写入到哪个特征； 第三个参数是通过此响应记录是否成功写入
//[self.peripherale writeValue:_batteryData forCharacteristic:self.characteristic type:CBCharacteristicWriteWithResponse];
-(void)printQRCodeWithImg:(UIImage *)QRCode withText:(NSString *)text{
    if (!self.characteristic) {
        return;
    }
    NSString*initInstruct = @"SIZE 48 mm,48 mm\r\nCLS\r\n";
    NSData *initInstructData = [initInstruct dataUsingEncoding:NSUTF8StringEncoding];
    //初始化
    [self.peripheral writeValue:initInstructData forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
    
    
//    QRCode = [self scaleToSize:QRCode size:CGSizeMake(280, 380)andText:text];

    //写入图片
    CGFloat width = QRCode.size.width;
    CGFloat height = QRCode.size.height;
    NSString *bitmap = [NSString stringWithFormat:@"BITMAP 40,30,%f,%f,1,",width/8,height];
    NSData *bitmapData = [bitmap dataUsingEncoding:NSUTF8StringEncoding];
    [self.peripheral writeValue:bitmapData forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
    
    NSData *imageData = [self covertToGrayScaleWithImage:QRCode];
    
    [self.peripheral writeValue:imageData forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
    [self.peripheral writeValue:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
    //结束命令
    NSString *endInstruct = @"PRINT 1,1\r\n";
    [self.peripheral writeValue:[endInstruct dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];
    
}
- (NSData *)getImageDataWithImage:(UIImage *)image{
    if (UIImagePNGRepresentation(image)) {
        return UIImagePNGRepresentation(image);
    }else{
        return UIImageJPEGRepresentation(image, 1);
    }
}


- (NSData *)escCovertToGrayScaleWithImage:(UIImage *)image left:(int) left{
    int width =image.size.width;
    int height =image.size.height;

    //像素将画在这个数组
    uint32_t *pixels = (uint32_t *)malloc(width *height *sizeof(uint32_t));
    //清空像素数组
    memset(pixels, 0, width*height*sizeof(uint32_t));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    //用 pixels 创建一个 context
    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width*sizeof(uint32_t), colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), image.CGImage);
    
    int tt = 1;
    int s = 0;
    
    Byte bytes[(width / 8 + left + 4) * height];
    Byte bitbuf[width / 8];
    int p[8]={0,0,0,0,0,0,0,0};
    for (int y = 0; y <height; y++) {
        for (int x =0; x <width/8; x ++) {
            for(int z = 0; z < 8; z++){
                uint8_t *rgbaPixel = (uint8_t *)&pixels[(y*width)+(x* 8+z)];
                
                int red = rgbaPixel[tt];
                int green = rgbaPixel[tt + 1];
                int blue = rgbaPixel[tt + 2];
                int gray = 0.29900 * red + 0.58700 * green + 0.11400 * blue; // 灰度转化公式
                if (gray <= 128) {
                    gray = 1;
                } else {
                    gray = 0;
                }
                p[z] = gray;
            }
            int value = (p[0] * 128 + p[1] * 64 + p[2] * 32 + p[3] * 16 + p[4] * 8 + p[5] * 4 + p[6] * 2 + p[7]);
            bitbuf[x] = value;
        }
        
        if(y != 0) {
            s = s+1;
            bytes[s] = 22;
        } else {
            bytes[s] = 22;
        }
        
        s = s + 1;
        bytes[s] = (width / 8 + left);
        
        for(int i = 0; i < left; i++){
            s = s + 1;
            bytes[s] = 0;
        }
        
        for(int n = 0; n < width/8;n++){
            s = s + 1;
            bytes[s] = bitbuf[n];
        }
        
        s = s + 1;
        bytes[s] = 21;
        s = s + 1;
        bytes[s] = 1;
    }
    free(pixels);
    NSData *data = [NSData dataWithBytes: bytes length: sizeof(bytes)];
    return data;
}

- (NSData *)covertToGrayScaleWithImage:(UIImage *)image{
    
    int width =image.size.width;
    int height =image.size.height;
    //像素将画在这个数组
    uint32_t *pixels = (uint32_t *)malloc(width *height *sizeof(uint32_t));
    //清空像素数组
    memset(pixels, 0, width*height*sizeof(uint32_t));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    //用 pixels 创建一个 context
    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width*sizeof(uint32_t), colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), image.CGImage);
    
    int tt =1;
    int bw = 0;
    Byte bytes[width / 8 * height];
    int p[8]={0,0,0,0,0,0,0,0};
    for (int y = 0; y <height; y++) {
        for (int x =0; x <width/8; x ++) {
            for(int z = 0; z < 8; z++){
                uint8_t *rgbaPixel = (uint8_t *)&pixels[(y*width)+(x* 8+z)];
                
                int red = rgbaPixel[tt];
                int green = rgbaPixel[tt + 1];
                int blue = rgbaPixel[tt + 2];
                int gray = 0.29900 * red + 0.58700 * green + 0.11400 * blue; // 灰度转化公式
                if (gray <= 128) {
                    gray = 0;
                } else {
                    gray = 1;
                }
                p[z] = gray;
            }
            int value = (p[0] * 128 + p[1] * 64 + p[2] * 32 + p[3] * 16 + p[4] * 8 + p[5] * 4 + p[6] * 2 + p[7]);
            bytes[bw] = value;
            bw++;
        }
    }
    free(pixels);
    NSData *data = [NSData dataWithBytes: bytes length: sizeof(bytes)];
    return data;

}

- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)newsize andText:(NSString *)text{
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, newsize.width, newsize.height)];
    contentView.backgroundColor = [UIColor whiteColor];
    UIImageView *imgView = [[UIImageView alloc] initWithImage:img];
    imgView.frame = CGRectMake(0, 0, newsize.width, newsize.width);
    [contentView addSubview:imgView];
    
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, newsize.width, newsize.width, 60)];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = text;
    label.font = [UIFont systemFontOfSize:32];
    label.backgroundColor = [UIColor whiteColor];
    [contentView addSubview:label];
    
    
    // 下面方法，第一个参数表示区域大小。第二个参数表示是否是非透明的。如果需要显示半透明效果，需要传NO，否则传YES。第三个参数就是屏幕密度了
    UIGraphicsBeginImageContextWithOptions(newsize, NO, [UIScreen mainScreen].scale);
    [contentView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
    
}

+(instancetype)shareBlueToothManager{
    static BlueToothManager *shareBlueToothManager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareBlueToothManager = [[BlueToothManager alloc] init];
    });
    return shareBlueToothManager;
}

- (void)statSearchPeripheral{
    self.cMgr = [[CBCentralManager alloc] initWithDelegate:[BlueToothManager shareBlueToothManager] queue:nil];
    self.peripheralsArray = [NSMutableArray array];
}

//只要中心管理者初始化 就会触发此代理方法 判断手机蓝牙状态
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    switch (central.state) {
        case 0:
            NSLog(@"CBCentralManagerStateUnknown");
            break;
        case 1:
            NSLog(@"CBCentralManagerStateResetting");
            break;
        case 2:
            NSLog(@"CBCentralManagerStateUnsupported");//不支持蓝牙
            break;
        case 3:
            NSLog(@"CBCentralManagerStateUnauthorized");
            break;
        case 4:{
            NSLog(@"CBCentralManagerStatePoweredOff");//蓝牙未开启
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请打开蓝牙" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            al.tag = 1000;
            [al show];
        }
            break;
        case 5:{
            NSLog(@"CBCentralManagerStatePoweredOn");//蓝牙已开启
            // 在中心管理者成功开启后再进行一些操作
            // 搜索外设
            [self.cMgr scanForPeripheralsWithServices:nil // 通过某些服务筛选外设
                                              options:nil]; // dict,条件
            // 搜索成功之后,会调用我们找到外设的代理方法
            // - (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI; //找到外设
        }
            break;
        default:
            break;
    }
}
// 发现外设后调用的方法
- (void)centralManager:(CBCentralManager *)central // 中心管理者
 didDiscoverPeripheral:(CBPeripheral *)peripheral // 外设
     advertisementData:(NSDictionary *)advertisementData // 外设携带的数据
                  RSSI:(NSNumber *)RSSI {// 外设发出的蓝牙信号强度
//    NSLog(@"%s, line = %d, cetral = %@,peripheral = %@, advertisementData = %@, RSSI = %@", __FUNCTION__, __LINE__, central, peripheral, advertisementData, RSSI);
    // 需要对连接到的外设进行过滤
    // 1.信号强度(40以上才连接, 80以上连接)
    // 2.通过设备名(设备字符串前缀是 OBand)
    // 在此时我们的过滤规则是:有OBand前缀并且信号强度大于35
    // 通过打印,我们知道RSSI一般是带-的
    //过滤一下
    int rssi = 0 - RSSI.intValue;
    if (40<rssi && rssi<200 && peripheral.name.length > 0) {
        if (![self.peripheralsArray containsObject:peripheral] ) {
            [self.peripheralsArray addObject:peripheral];
            self.searchAllCBPeripheralHandler(self.peripheralsArray);
        }
    }
//    if ([peripheral.name hasPrefix:@"MHT"]) {
//        // 在此处对我们的 advertisementData(外设携带的广播数据) 进行一些处理
//        // 标记我们的外设,让他的生命周期 = vc
//        self.peripheral = peripheral;
//        // 发现完之后就是进行连接
//        [self.cMgr connectPeripheral:self.peripheral options:nil];
//    }
}
// 中心管理者连接外设成功
- (void)centralManager:(CBCentralManager *)central // 中心管理者
  didConnectPeripheral:(CBPeripheral *)peripheral // 外设
{
    self.peripheral = peripheral;
    [self showAlertWithMessage:[NSString stringWithFormat:@"%s, line = %d, %@=连接成功", __FUNCTION__, __LINE__, peripheral.name]];
    // 连接成功之后,可以进行服务和特征的发现
    //  设置外设的代理
    self.peripheral.delegate = self;
    
    // 外设发现服务,传nil代表不过滤
    // 这里会触发外设的代理方法 - (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
    [self.peripheral discoverServices:nil];

}
// 外设连接失败
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    [self showAlertWithMessage:[NSString stringWithFormat:@"%s, line = %d, %@=连接失败", __FUNCTION__, __LINE__, peripheral.name]];
    
}

// 丢失连接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"%s, line = %d, %@=断开连接", __FUNCTION__, __LINE__, peripheral.name);
}


- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    for (CBService *services in peripheral.services) {
        [peripheral discoverCharacteristics:nil forService:services];
    }
}
static void extracted(CBCharacteristic *cha, CBPeripheral * _Nonnull peripheral) {
    [peripheral readValueForCharacteristic:cha];
}

// 发现外设服务里的特征的时候调用的代理方法(这个是比较重要的方法，你在这里可以通过事先知道UUID找到你需要的特征，订阅特征，或者这里写入数据给特征也可以)
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    for (CBCharacteristic *cha in service.characteristics) {
            extracted(cha, peripheral);
            //设置 characteristic 的 notifying 属性 为 true ， 表示接受广播
            [peripheral setNotifyValue:YES forCharacteristic:cha];
    };

}

// 更新特征的value的时候会调用 （凡是从蓝牙传过来的数据都要经过这个回调，简单的说这个方法就是你拿数据的唯一方法） 你可以判断是否
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    //characteristic.value就是你要的数据
    for (CBCharacteristic * chara in characteristic.service.characteristics) {
        if (chara.properties == 0x3E || chara.properties == 0xC) {
            self.characteristic = characteristic;
        }
    }

}
// 需要注意的是特征的属性是否支持写数据
- (void)yf_peripheral:(CBPeripheral *)peripheral didWriteData:(NSData *)data forCharacteristic:(nonnull CBCharacteristic *)characteristic
{
    /*
     typedef NS_OPTIONS(NSUInteger, CBCharacteristicProperties) {
     CBCharacteristicPropertyBroadcast                                                = 0x01,
     CBCharacteristicPropertyRead                                                    = 0x02,
     CBCharacteristicPropertyWriteWithoutResponse                                    = 0x04,
     CBCharacteristicPropertyWrite                                                    = 0x08,
     CBCharacteristicPropertyNotify                                                    = 0x10,
     CBCharacteristicPropertyIndicate                                                = 0x20,
     CBCharacteristicPropertyAuthenticatedSignedWrites                                = 0x40,
     CBCharacteristicPropertyExtendedProperties                                        = 0x80,
     CBCharacteristicPropertyNotifyEncryptionRequired NS_ENUM_AVAILABLE(NA, 6_0)        = 0x100,
     CBCharacteristicPropertyIndicateEncryptionRequired NS_ENUM_AVAILABLE(NA, 6_0)    = 0x200
     };
     
     打印出特征的权限(characteristic.properties),可以看到有很多种,这是一个NS_OPTIONS的枚举,可以是多个值
     常见的又read,write,noitfy,indicate.知道这几个基本够用了,前俩是读写权限,后俩都是通知,俩不同的通知方式
     */
    //    NSLog(@"%s, line = %d, char.pro = %d", __FUNCTION__, __LINE__, characteristic.properties);
    // 此时由于枚举属性是NS_OPTIONS,所以一个枚举可能对应多个类型,所以判断不能用 = ,而应该用包含&
}
- (void)showAlertWithMessage:(NSString *)message{
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [al show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
}

- (NSMutableArray *)peripheralsArray{
    if (!_peripheralsArray) {
        _peripheralsArray = [NSMutableArray array];
    }
    return _peripheralsArray;
}

@end
